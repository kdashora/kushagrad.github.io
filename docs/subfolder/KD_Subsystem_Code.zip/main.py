
# KD Final ESP32 Firmware (Updated for Ian's Message Format + Type 3 and 4 support)
# Author: Kushagra Dashora

import uasyncio as asyncio
import network
import socket
import time
import json
import ssl
from machine import UART, Pin
from mqtt_as.mqtt_as import MQTTClient
from mqtt_as.mqtt_local import config, wifi_led, blue_led
from config import *

TEAM = 'EGR314/Team306/'
TOPIC_HB = TEAM + 'heartbeat'
TOPIC_PUB = TEAM + 'PUB'
TOPIC_SUB = TEAM + 'SUB'

START_SEQ = b"AZ"
END_SEQ = b"YB"
MIN_SENSOR_MSG_LEN = 10
MY_ID = 0x6B
BROADCAST_ID = 0x58

ID_NAME_MAP = {
    0x69: "Ian",
    0x63: "Alex",
    0x61: "Aarshon",
    0x6B: "Kushagra",
    0x58: "Broadcast"
}

uart = UART(2, baudrate=9600, tx=43, rx=44)
led_ian = Pin(35, Pin.OUT)
led_alex = Pin(38, Pin.OUT)

def blink(led_pin, duration_ms=300):
    led_pin.value(1)
    time.sleep_ms(duration_ms)
    led_pin.value(0)

def parse_sensor_message(msg):
    if len(msg) != MIN_SENSOR_MSG_LEN:
        return None
    if not msg.startswith(START_SEQ) or not msg.endswith(END_SEQ):
        return None
    sensor_val = (msg[6] << 8) | msg[7]
    return {
        "sender": msg[2],
        "receiver": msg[3],
        "msg_type": msg[4],
        "sensor_num": msg[5],
        "sensor_val": sensor_val
    }

async def handle_sensor(parsed, sender, receiver):
    sensor_map = {1: "wind", 2: "temp", 3: "humid", 4: "pressure"}
    label = sensor_map.get(parsed['sensor_num'], "unknown")
    if label != "unknown":
        sensor_val = parsed['sensor_val']
        if label == "wind":
            print(f"[SENSOR] Wind Speed: {(sensor_val-256) / 100:.2f} mph")
        elif label == "temp":
            print(f"[SENSOR] Temperature: {sensor_val / 100:.2f} °C")
        elif label == "humid":
            print(f"[SENSOR] Humidity: {sensor_val / 100:.2f} %")
        elif label == "pressure":
            print(f"[SENSOR] Air Pressure: {sensor_val / 10:.1f} mbar")
        payload = {label: sensor_val / 100 if label in ["temp", "humid"] else sensor_val}
        json_payload = json.dumps(payload)
        await client.publish(TOPIC_PUB, json_payload, qos=1)
        print(f"[MQTT] Published {payload}")

def forward_to_aarshon(raw_data):
    fwd = bytearray(raw_data)
    fwd[3] = 0x61
    uart.write(fwd)
    print("[FORWARD] Forwarded to Aarshon")

def send_alex_motor_command(direction, angle):
    msg = bytearray()
    msg += START_SEQ
    msg.append(0x6B)
    msg.append(0x63)
    msg.append(0x32)
    msg.append(direction)
    msg.append(angle)
    msg += END_SEQ
    uart.write(msg)
    print(f"[ACTION] Sent command to Alex → Direction: {direction}, Angle: {angle}")

# UART Receiver with type 3 and 4 support
async def receiver():
    stream = b""
    sreader = asyncio.StreamReader(uart)
    while True:
        c = await sreader.read(1)
        if not c:
            await asyncio.sleep_ms(20)
            continue
        stream += c

        if stream.endswith(START_SEQ):
            stream = START_SEQ

        if len(stream) >= 64 or stream.endswith(END_SEQ):
            if not stream.startswith(START_SEQ) or not stream.endswith(END_SEQ):
                print("[ERROR] Invalid framing.")
                stream = b""
                continue

            sender = stream[2]
            receiver = stream[3]
            msg_type = stream[4]

            # Type 1: Sensor message
            if msg_type == 0x31 and len(stream) >= 10 and receiver in (MY_ID, BROADCAST_ID):
                sensor_val = (stream[6] << 8) | stream[7]
                parsed = {
                    "sender": sender,
                    "receiver": receiver,
                    "msg_type": msg_type,
                    "sensor_num": stream[5],
                    "sensor_val": sensor_val
                }
                blink(led_ian if sender == 0x69 else led_alex)
                print("[INFO] Interpreting Type 1 message")
                await handle_sensor(parsed, sender, receiver)
                if receiver == BROADCAST_ID:
                    forward_to_aarshon(stream)

            # Type 3: Subsystem Status Code
            elif msg_type == 0x33 and len(stream) >= 6 and receiver == MY_ID:
                error_code = stream[5]
                name = {0x63: "Alex", 0x69: "Ian", 0x6B: "Kushagra"}.get(sender, "Unknown")
                status_map = {1: "Full functionality", 2: "Partial functionality", 3: "No functionality"}
                status = status_map.get(error_code, "Unknown status")
                print(f"[STATUS] From {name}: {status}")

            # Type 4: Subsystem Error Message
            elif msg_type == 0x34 and receiver == MY_ID:
                try:
                    name = {0x63: "Alex", 0x69: "Ian", 0x6B: "Kushagra"}.get(sender, "Unknown")
                    msg_bytes = stream[5:-2]
                    error_msg = "".join(chr(b) for b in msg_bytes if b >= 32 and b <= 126)
                    print(f"[ERROR] From {name}: {error_msg}")
                except Exception as e:
                    print(f"[ERROR] Could not decode error message: {e}")

            # Forward everything else
            else:
                print("[INFO] Forwarding uninterpreted message")
                uart.write(stream)

            stream = b""  # Clear buffer

        await asyncio.sleep_ms(20)


def sub_cb(topic, msg, retained):
    topic_str = topic.decode()
    msg_str = msg.decode()
    print(f"[MQTT] Incoming → Topic: {topic_str}, Message: {msg_str}")
    try:
        parts = msg_str.strip().split()
        if len(parts) == 2:
            direction = int(parts[0])
            angle = int(parts[1])
            if direction in (1, 2) and 0 <= angle <= 255:
                send_alex_motor_command(direction, angle)
            else:
                print("[ERROR] Invalid direction or angle range")
        else:
            print("[ERROR] Payload format must be: <1or2> <angle>")
    except Exception as e:
        print(f"[ERROR] Parsing MQTT payload failed: {e}")

def conn_han(client):
    print("[MQTT] Connected! Subscribing to:", TOPIC_SUB)
    return client.subscribe(TOPIC_SUB, 1)

async def wifi_han(state):
    wifi_led(not state)
    print("[WiFi]", "UP" if state else "DOWN")
    await asyncio.sleep(1)

config.update({
    "server": MQTT_SERVER,
    "ssid": WIFI_SSID,
    "wifi_pw": WIFI_PASSWORD,
    "ssl": True,
    "ssl_params": {
        "cert": open('certs/student_crt.pem', 'rb').read(),
        "key": open('certs/student_key.pem', 'rb').read(),
        "cadata": open('certs/ca_crt.pem', 'rb').read(),
        "server_hostname": MQTT_SERVER,
        "cert_reqs": ssl.CERT_REQUIRED
    },
    "port": 8883,
    "subs_cb": sub_cb,
    "wifi_coro": wifi_han,
    "connect_coro": conn_han,
    "clean": True,
    "user": MQTT_USER,
    "password": MQTT_PASSWORD
})

client = MQTTClient(config)
MQTTClient.DEBUG = True

async def main():
    print("[BOOT] Connecting WiFi and MQTT...")
    try:
        await client.connect()
    except OSError:
        print("[ERR] MQTT connect failed.")
        return
    print("[BOOT] MQTT connected. Starting tasks...")
    asyncio.create_task(receiver())
    while True:
        await asyncio.sleep(1)

try:
    asyncio.run(main())
finally:
    client.close()
    asyncio.new_event_loop()
