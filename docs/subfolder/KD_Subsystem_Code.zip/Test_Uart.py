import paho.mqtt.publish as publish
import time

BROKER = "52.25.206.167"
TOPIC = "EGR314/Team306/SUB"
AUTH = {
    "username": "student",
    "password": "egr3x4"
}

test_cases = {
    "Ian (Type 1)": b'\x12\x01\x02\x03\x04',
    "Alex (Type 3)": b'\x69\x03\x00\x00\x00',
    "KD (Type 4)": b'\x11\x04\x00\x00\x00',
    "Unknown": b'\xFF\x01\x02\x03\x04'
}

for name, payload in test_cases.items():
    print(f"Sending: {name}")
    publish.single(
    topic=TOPIC,
    payload=b'\x12\x01\x02\x03\x04',
    hostname=BROKER,
    port=8883,
    auth=AUTH,
    tls={"ca_certs": "ca_crt.pem"}  # Or None if not checking
)

    time.sleep(1)
